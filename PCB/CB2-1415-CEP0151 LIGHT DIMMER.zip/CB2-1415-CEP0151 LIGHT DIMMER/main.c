#include<pic.h>
#include"pic_lcd8.h"
#define inc RC0
#define dec RC1

unsigned int a;
void main()
{
	TRISB=0X00;
	TRISD=0X00;
	TRISC=0X03;
//	TRISA=0X03;
		
  	Lcd8_Init();
  	Lcd8_Display(0x80,"  LIGHT DIMMER  ",16);
	PORTB=0;
	a=220;
  	while(1)
 	{
		
		if(!inc)
		{
			a++;
			PORTB=a;
			Delay(32500);
			if(a>254){a=254;}

		/*	for(a=b;a<=255;a++)
			{
				PORTB=a;
				Delay(65000);
				Lcd8_Decimal3(0xc0,a);
				if(inc)break;
	
            }*/
			
		}
		if(!dec)
		{
			a--;
			PORTB=a;
			Delay(32500);
			if(a<220){a=220;}
		/*	for(a=c;a>=220;a--)
			{
				PORTB=a;
				Delay(65000);
				Lcd8_Decimal3(0xc0,a);
				if(inc)break;
	
            }*/
			
		}

	
	
		
		
		
 	}
}															